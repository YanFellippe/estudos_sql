INSERT INTO tb_tipo_artista
	(id,nome)
VALUES
	(1, 'Banda'),
    (2, 'Solo'),
    (3, 'Dupla'),
    (4, 'Grupo'),
    (5, 'Conjunto');